/***
 * Clase que se encarga de realizar las Controller de la ventana de View. Esta
 * es la representacion del controlador quien recibe los eventos gestionados por
 * el usuario
 *
 */
public class Controller {
 
   /**
    * Se instancia la clase Model y se invoca el metodo validar el cual devuelve
    * un boolean con el resultado de la validacion
    *
    * @param usuario
    * @param clave
    * @return
    */
   public boolean validar(String usuario, String clave) {
      Model Model = new Model();
      return Model.validar(usuario, clave);
   }
}