
 
/**
 * Esta clase se encarga de manejar la parte de "persistencia" de los datos y
 * genera la validacion de un usuario que se loguea en la aplicacion. Esta es la
 * representacion del modelo.
 *
 */

public class Model {
   private String usuarios[];
   private String claves[];
   
 
   public Model() {
      usuarios = new String[2];
      claves = new String[2];
 
      cargarDatos();
   }
 
   private void cargarDatos() {
	
         usuarios[0] = "admin";
         claves[0] = "admin";
         usuarios[1] = "system";
         claves[1] = "system";


       //muestro el array  
       for (int i = 0; i < usuarios.length; i++) {
    	   System.out.println((i +1) + " usuario: " +usuarios[i] + " / contrase�a: " + claves[i]); }
       
   }
 
   public boolean validar(String usuario, String clave) {
 
      for (int i = 0; i < usuarios.length && usuarios[i] != null; i++) {
         if (usuarios[i].equals(usuario) && claves[i].equals(clave)) {
            return true;
         }
      }
      return false;
   }
 
   public static void main(String[] args) {
      Model Model = new Model();
   }
 
}