
	import java.awt.Button;
	import java.awt.Color;
	import java.awt.Font;
	import java.awt.Frame;
	import java.awt.Label;
	import java.awt.TextField;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.awt.event.WindowAdapter;
	import java.awt.event.WindowEvent;
	import javax.swing.JFrame;
	import javax.swing.JOptionPane;
import javax.swing.SpringLayout;
	 
	/**
	 * Clase que muestra una ventana de View y simula la validacion de un usuario
	 * tomado de un arreglo de datos definidos en la clase Model.
	 *
	 * 
	 *
	 */
	public class View extends JFrame implements ActionListener {
	 
	   //1 Atributos de la clase
	   private Frame ventana;
	   private Button botonValidar;
	   private Label lusuario;
	   private Label lclave;
	   private Label lerror;
	   private TextField tusuario;
	   private TextField tclave;
	   private final int ancho = 400;
	   private final int alto = 320;
	   private final int x = 350;
	   private final int y = 230;
	 
	   //2 constructor que pinta la clase con los dos m�todos de la clase
	   public View() {
	      pintarVentana();
	      eventosVentana();
	   }
	 
	   //3 primer m�todo configuraci�n de la ventana
	   public void pintarVentana() {
		   
	      // Instancia de la ventana y titulo
	      ventana = new Frame(".:: Acceso de Usuarios ::.");
	      SpringLayout layout = new SpringLayout();
	      
	      // Defino la posicion y el tama�o de la ventana
	      ventana.setBounds(x, y, ancho, alto);
	      ventana.setLayout(null);
	      ventana.setBackground(Color.white);
	      ventana.setForeground(Color.darkGray);
	 
	      // Labels
	      lusuario = new Label("Usuario : ");
	      lusuario.setBounds(80, 150, 100, 25);
	      lusuario.setFont(new Font("verdana", Font.TRUETYPE_FONT, 14));
	      lclave = new Label("Clave    : ");
	      lclave.setBounds(80, 180, 100, 25);
	      lclave.setFont(new Font("verdana", Font.TRUETYPE_FONT, 14));

	 
	      // TextFields
	      tusuario = new TextField();
	      tusuario.setBounds(185, 150, 100, 25);
	      tusuario.setForeground(Color.black);
	      tusuario.setFont(new Font("verdana", Font.BOLD, 12));
	      tclave = new TextField();
	      tclave.setBounds(185, 180, 100, 25);
	      tclave.setForeground(Color.black);
	      tclave.setEchoChar('*');
	      tclave.setFont(new Font("verdana", Font.BOLD, 12));
	 
	      // Botones
	      botonValidar = new Button(" Validar ");
	      botonValidar.setBounds(160, 250, 100, 30);
	      botonValidar.addActionListener(this);
	      botonValidar.setForeground(Color.black);
	 
	      // Adicion de componentes
	      ventana.add(botonValidar);
	      ventana.add(lusuario);
	      ventana.add(lclave);
	      ventana.add(tusuario);
	      ventana.add(tclave);
	   }//Fin m�todo pintarVentana
	 
	  //4.  segundo m�todo eventos
	   private void eventosVentana() {
	      //Manejo de eventos de la ventana
	      ventana.addWindowListener(new WindowAdapter() {
	         
	    	  // a.Cerrando ventana
	         public void windowClosing(WindowEvent e) {
	            System.out.println("Se ha cerrado la ventana");
	            System.exit(0);
	         }
	 
	         // b. Ventana abierta
	         public void windowOpened(WindowEvent e) {
	            System.out.println("Ventana abierta");
	         }
	 
	         // c. Ventana activa
	         public void windowActivated(WindowEvent e) {
	            System.out.println("Ventana activa");
	         }
	 
	         // d. Ventana inactiva
	         public void windowDeactivated(WindowEvent e) {
	            System.out.println("Ventana inactiva");
	         }
	 
	         // e. Se minimiza la ventana
	         public void windowIconified(WindowEvent e) {
	            System.out.println("Ventana minimizada");
	         }
	 
	         // f. Se maximiza la ventana
	         public void windowDeiconified(WindowEvent e) {
	            System.out.println("Ventana restaurada");
	         }
	      });
	 
	   }
	 
	   //5. Actuaci�n de los eventos
	   public void actionPerformed(ActionEvent e) {
		   
	      // a. Pulsar el boton validar
	      
		   if (e.getSource() == botonValidar) {
	         String usuario = tusuario.getText();
	         String clave = tclave.getText();
	 
	         Controller operacion = new Controller();
	 
	         if (operacion.validar(usuario, clave)) {
	            //JOptionPane.showMessageDialog(ventana, " Bienvenido " + usuario
	                 // + "!", " Validacion View ",
	                 // JOptionPane.INFORMATION_MESSAGE);
	        ventana.setForeground(Color.darkGray);
	   	      lerror = new Label("B i e n v e n i d o");
		      lerror.setBounds(110, 90, 300, 40);
		      lerror.setFont(new Font("calibri", Font.PLAIN, 25));
		      ventana.add(lerror);
	         } else {
	        	 ventana.setForeground(Color.black);
	        	 lerror = new Label("acceso denegado");
			     lerror.setBounds(160, 220, 100, 12);
			     lerror.setFont(new Font("calibri light", Font.BOLD, 10));
			     ventana.add(lerror);
	         }
	      }
	   }
	 
	   /**
	    * Muestra la ventana
	    */
	   public void mostrar() {
	      ventana.setVisible(true);
	   }
	 
	   /**
	    * Metodo main de la clase que se encarga el arreglo
	    *
	    * @param args
	    */
	   public static void main(String[] args) {
	      // Creacion del objeto View
	      View View = new View();
	      View.mostrar();
	   }
	 
	

}


